
package com.alexandre.controleiot;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.text.InputFilter;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.*;

import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final String DEFAULT_HOST =
            "436ce1fa7ecd416c98446bce794c0d8d.s1.eu.hivemq.cloud";

    private static final String DEFAULT_PORT = "8884";
    private static final String DEFAULT_PREFIX = "iotaula/seu-nome";

    private static final String TOPIC_LED_SET = "/led/set";
    private static final String TOPIC_LED_STATE = "/led/state";
    private static final String TOPIC_MESSAGE = "/msg";
    private static final String TOPIC_TEMP = "/temp";
    private static final String TOPIC_STATUS = "/status";

    private EditText host, port, prefix;
    private EditText userInput, passwordInput;
    private EditText fromInput, messageInput;

    private TextView connection;
    private TextView ledState;
    private TextView temperature;
    private TextView humidity;
    private TextView espStatus;
    private TextView lastReading;

    private MqttClient mqttClient;

    private final ExecutorService executor =
            Executors.newSingleThreadExecutor();

    private volatile boolean connecting = false;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(24, 18, 24, 18);
        layout.setBackgroundColor(Color.rgb(248, 249, 252));

        ScrollView scroll = new ScrollView(this);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);

        scroll.addView(body);

        body.addView(text("Controle IoT - MQTT", 24));

        host = input(body, "Host MQTT", DEFAULT_HOST);
        port = input(body, "Porta", DEFAULT_PORT);

        userInput = input(body, "Usuário MQTT", "aula");
        passwordInput = input(body, "Senha MQTT", "12345678");

        passwordInput.setInputType(
                InputType.TYPE_CLASS_TEXT |
                        InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        prefix = input(body, "Prefixo dos tópicos", DEFAULT_PREFIX);

        Button connectButton = button(body, "Conectar ao HiveMQ");

        connection = text("Desconectado", 15);
        body.addView(connection);

        connectButton.setOnClickListener(v -> connect());

        Button disconnectButton = button(body, "Desconectar");
        disconnectButton.setOnClickListener(v -> disconnect());

        body.addView(text("CONTROLE DO LED", 18));

        ledState = text("Estado do LED: aguardando ESP32", 16);
        body.addView(ledState);

        button(body, "LIGAR LED").setOnClickListener(v ->
                publish(TOPIC_LED_SET, "ON")
        );

        button(body, "DESLIGAR LED").setOnClickListener(v ->
                publish(TOPIC_LED_SET, "OFF")
        );

        body.addView(text("ENVIAR MENSAGEM", 18));

        fromInput = input(
                body,
                "Seu nome (máximo 15 caracteres)",
                ""
        );

        fromInput.setFilters(new InputFilter[]{
                new InputFilter.LengthFilter(15)
        });

        messageInput = input(
                body,
                "Mensagem (máximo 16 caracteres)",
                ""
        );

        messageInput.setFilters(new InputFilter[]{
                new InputFilter.LengthFilter(16)
        });

        button(body, "Enviar mensagem").setOnClickListener(v -> {

            String nome = fromInput.getText().toString().trim();
            String mensagem = messageInput.getText().toString().trim();

            if (nome.isEmpty() || mensagem.isEmpty()) {
                Toast.makeText(
                        this,
                        "Preencha seu nome e mensagem.",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            try {
                JSONObject json = new JSONObject();
                json.put("from", nome);
                json.put("text", mensagem);

                publish(TOPIC_MESSAGE, json.toString());

            } catch (Exception e) {
                Toast.makeText(
                        this,
                        "Erro ao criar mensagem.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        body.addView(text("LEITURA DO SENSOR", 18));

        temperature = text("Temperatura: -- °C", 17);
        humidity = text("Umidade: -- %", 17);
        lastReading = text("Última leitura: aguardando", 14);

        body.addView(temperature);
        body.addView(humidity);
        body.addView(lastReading);

        body.addView(text("STATUS DO ESP32", 18));

        espStatus = text("ESP32: desconhecido", 16);
        body.addView(espStatus);

        layout.addView(
                scroll,
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                )
        );

        setContentView(layout);
    }

    private EditText input(
            LinearLayout parent,
            String hint,
            String value
    ) {
        EditText edit = new EditText(this);

        edit.setHint(hint);
        edit.setText(value);
        edit.setSingleLine(true);

        edit.setTextColor(Color.BLACK);
        edit.setHintTextColor(Color.GRAY);

        edit.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(Color.GRAY)
        );

        parent.addView(
                edit,
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                )
        );

        return edit;
    }

    private TextView text(String value, int size) {
        TextView t = new TextView(this);

        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(Color.BLACK);
        t.setPadding(0, 12, 0, 12);

        return t;
    }

    private Button button(LinearLayout parent, String label) {
        Button b = new Button(this);

        b.setText(label);
        parent.addView(b);

        return b;
    }

    private String topic(String suffix) {
        String p = prefix.getText().toString().trim();

        while (p.endsWith("/")) {
            p = p.substring(0, p.length() - 1);
        }

        return p + suffix;
    }

    private void connect() {

        if (connecting) return;

        if (mqttClient != null && mqttClient.isConnected()) {
            Toast.makeText(
                    this,
                    "Já está conectado.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        final String broker =
                "wss://" + host.getText().toString().trim()
                        + ":" + port.getText().toString().trim()
                        + "/mqtt";

        final String username =
                userInput.getText().toString().trim();

        final String password =
                passwordInput.getText().toString();

        final String studentPrefix =
                prefix.getText().toString().trim();

        if (broker.contains(" ") ||
                username.isEmpty() ||
                password.isEmpty() ||
                studentPrefix.isEmpty()) {

            Toast.makeText(
                    this,
                    "Confira os dados de conexão.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        connecting = true;
        connection.setText("Conectando ao HiveMQ...");

        executor.execute(() -> {

            try {

                String studentId = studentPrefix.substring(
                        studentPrefix.lastIndexOf("/") + 1
                );

                String clientId = "app-" + studentId + "-"
                        + UUID.randomUUID().toString().substring(0, 8);

                mqttClient = new MqttClient(
                        broker,
                        clientId,
                        new MemoryPersistence()
                );

                mqttClient.setCallback(new MqttCallback() {

                    @Override
                    public void connectionLost(Throwable cause) {

                        String erro = cause != null
                                ? cause.toString()
                                : "Motivo desconhecido";

                        runOnUiThread(() ->
                                connection.setText(
                                        "Conexão perdida: " + erro
                                )
                        );
                    }

                    @Override
                    public void messageArrived(
                            String receivedTopic,
                            MqttMessage mqttMessage
                    ) {

                        receiveMessage(
                                receivedTopic,
                                new String(
                                        mqttMessage.getPayload(),
                                        StandardCharsets.UTF_8
                                )
                        );
                    }

                    @Override
                    public void deliveryComplete(
                            IMqttDeliveryToken token
                    ) {
                    }
                });

                MqttConnectOptions options =
                        new MqttConnectOptions();

                options.setUserName(username);
                options.setPassword(password.toCharArray());

                options.setMqttVersion(
                        MqttConnectOptions.MQTT_VERSION_3_1_1
                );

                options.setCleanSession(true);
                options.setAutomaticReconnect(true);
                options.setConnectionTimeout(20);
                options.setKeepAliveInterval(30);

                mqttClient.connect(options);

                subscribeTopics();

                runOnUiThread(() ->
                        connection.setText("Conectado ao HiveMQ!")
                );

            } catch (Exception e) {

                String erro = e.toString();

                runOnUiThread(() ->
                        connection.setText("Erro de conexão: " + erro)
                );

            } finally {
                connecting = false;
            }
        });
    }

    private void subscribeTopics() {

        try {

            if (mqttClient == null || !mqttClient.isConnected()) {
                return;
            }

            mqttClient.subscribe(topic(TOPIC_LED_STATE));
            mqttClient.subscribe(topic(TOPIC_TEMP));
            mqttClient.subscribe(topic(TOPIC_STATUS));

        } catch (MqttException e) {

            runOnUiThread(() ->
                    connection.setText(
                            "Erro ao assinar tópicos: " + e.getMessage()
                    )
            );
        }
    }

    private void publish(String suffix, String payload) {

        executor.execute(() -> {

            try {

                if (mqttClient == null || !mqttClient.isConnected()) {

                    runOnUiThread(() ->
                            Toast.makeText(
                                    this,
                                    "Conecte ao HiveMQ primeiro.",
                                    Toast.LENGTH_SHORT
                            ).show()
                    );

                    return;
                }

                String fullTopic = topic(suffix);

                MqttMessage message = new MqttMessage(
                        payload.getBytes(StandardCharsets.UTF_8)
                );

                message.setQos(0);
                message.setRetained(false);

                mqttClient.publish(fullTopic, message);

                runOnUiThread(() ->
                        Toast.makeText(
                                this,
                                "Mensagem enviada!",
                                Toast.LENGTH_SHORT
                        ).show()
                );

            } catch (Exception e) {

                runOnUiThread(() ->
                        Toast.makeText(
                                this,
                                "Erro ao enviar: " + e.getMessage(),
                                Toast.LENGTH_LONG
                        ).show()
                );
            }
        });
    }

    private void receiveMessage(
            String receivedTopic,
            String payload
    ) {

        runOnUiThread(() -> {

            if (receivedTopic.equals(topic(TOPIC_LED_STATE))) {

                ledState.setText("Estado do LED: " + payload);

            } else if (receivedTopic.equals(topic(TOPIC_TEMP))) {

                try {

                    JSONObject json = new JSONObject(payload);

                    double t = json.getDouble("t");

                    temperature.setText(
                            String.format(
                                    Locale.getDefault(),
                                    "Temperatura: %.1f °C",
                                    t
                            )
                    );

                    if (json.has("h") && !json.isNull("h")) {

                        double h = json.getDouble("h");

                        humidity.setText(
                                String.format(
                                        Locale.getDefault(),
                                        "Umidade: %.1f %%",
                                        h
                                )
                        );

                    } else {
                        humidity.setText("Umidade: indisponível");
                    }

                    String time = new SimpleDateFormat(
                            "dd/MM/yyyy HH:mm:ss",
                            Locale.getDefault()
                    ).format(new Date());

                    lastReading.setText("Última leitura: " + time);

                } catch (Exception e) {

    android.util.Log.e(
            "MQTT_SENSOR",
            "Mensagem recebida: " + payload,
            e
    );

    lastReading.setText(
            "Erro ao interpretar: " + payload
    );
}

            } else if (receivedTopic.equals(topic(TOPIC_STATUS))) {

                espStatus.setText("ESP32: " + payload);
            }
        });
    }

    private void disconnect() {

        executor.execute(() -> {

            try {

                if (mqttClient != null && mqttClient.isConnected()) {
                    mqttClient.disconnect();
                }

                runOnUiThread(() -> {

                    connection.setText("Desconectado");

                    Toast.makeText(
                            this,
                            "Desconectado do HiveMQ.",
                            Toast.LENGTH_SHORT
                    ).show();
                });

            } catch (Exception e) {

                runOnUiThread(() ->
                        connection.setText(
                                "Erro ao desconectar: " + e.getMessage()
                        )
                );
            }
        });
    }

    @Override
    protected void onDestroy() {

        executor.execute(() -> {

            try {

                if (mqttClient != null && mqttClient.isConnected()) {
                    mqttClient.disconnect();
                }

                if (mqttClient != null) {
                    mqttClient.close();
                }

            } catch (Exception ignored) {
            }
        });

        executor.shutdown();

        super.onDestroy();
    }
}
