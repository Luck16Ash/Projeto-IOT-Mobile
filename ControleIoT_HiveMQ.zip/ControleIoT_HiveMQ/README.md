# Controle IoT MQTT - HiveMQ

Aplicativo Android em Java para publicar comandos MQTT e o nome do aluno.

## Padrões
- Host: `broker.hivemq.com`
- Porta: `1883`
- Prefixo: `luca-dsm`

## Tópicos
- LED: `luca-dsm/casa/sala/led` (publica `ON` ou `OFF`)
- Nome: `luca-dsm/aluno/nome` (publica o texto digitado)
- Temperatura: `luca-dsm/casa/sala/temperatura` (assina)
- Estado LED: `luca-dsm/casa/sala/led/estado` (assina)
- Status: `luca-dsm/casa/sala/status` (assina)

## Abrir e gerar APK
1. Extraia o ZIP.
2. No Android Studio, use **Open** e escolha a pasta `ControleIoT_HiveMQ` (a que contém `settings.gradle`).
3. Aguarde o Gradle Sync e aceite instalar os componentes do SDK se solicitado.
4. Vá em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Onde mudar
Arquivo `app/src/main/java/com/alexandre/controleiot/MainActivity.java`:
- `DEFAULT_HOST` e `DEFAULT_PORT`: broker e porta.
- `DEFAULT_PREFIX`: prefixo dos tópicos.
- `TOPIC_NAME`: tópico em que o app publica o nome.
- `TOPIC_LED`: tópico de comando do LED.

Host, porta e prefixo também podem ser alterados diretamente nos campos da tela.
Confirme com o professor o tópico exato para o nome; se ele fornecer outro, atualize `TOPIC_NAME` (ou o prefixo) e faça novo build.

O HiveMQ público é aberto para testes. Não envie dados privados.
